﻿//Karta bohatera 3.0
Console.ResetColor();

Console.Write("Name? "); string name = Console.ReadLine();
Console.Write("HP? "); int hp = int.Parse(Console.ReadLine()); 
Console.Write("LvL? "); int lvl = int.Parse(Console.ReadLine());
Console.Write("Gold? "); int gold = int.Parse(Console.ReadLine());
Console.Write("Power? "); int power = int.Parse(Console.ReadLine());
Console.Write("Potions? "); int potions = int.Parse(Console.ReadLine());
Console.Write("Map? "); bool map = bool.Parse(Console.ReadLine());

bool kompas = false;
bool Zyje = hp > 0;
bool LowHP = hp < 25 && Zyje == true;
bool ReadyToGo = Zyje == true && map == true || kompas == true;
bool rich = gold >= 100;

//karta
Console.WriteLine("+=======================+");
Console.WriteLine($"|Name: {name}\t\t|");
Console.WriteLine($"|Hp: {hp}\t\t|");
Console.WriteLine($"|LvL: {lvl}\t\t|");
Console.WriteLine($"|Gold: {gold}\t\t|");
Console.WriteLine($"|Power: {power}\t\t|");
Console.WriteLine($"|Potions: {potions}\t\t|");
Console.WriteLine($"|Map: {map}\t\t|");
Console.WriteLine("+-----------------------+");
if (Zyje == true)
{
    Console.Write("|");
    Console.ForegroundColor = ConsoleColor.Green;
    Console.Write($"Żyje: {Zyje}");
    Console.ResetColor();
    Console.WriteLine("\t\t|");
}
else
{
    Console.Write("|");
    Console.ForegroundColor = ConsoleColor.Red;
    Console.Write($"Żyje: {Zyje}");
    Console.ResetColor();
    Console.WriteLine("\t\t|");
}
Console.WriteLine($"|LowHp: {LowHP}\t\t|");
Console.WriteLine($"|ReadyToGo: {ReadyToGo}\t|");
Console.WriteLine($"|Rich: {rich}\t\t|");
Console.WriteLine("+=======================+");

//menu
Console.WriteLine("+=======================+");
Console.WriteLine("|Wybierz akcje\t\t|");
Console.WriteLine("+=======================+");
Console.WriteLine("|1 Sprawdz stan \t|");
Console.WriteLine("|2 rozpocznij wyprawe \t|");
Console.WriteLine("|3 przygotuj miksture \t|");
Console.WriteLine("|4 odpocznij \t\t|");
Console.WriteLine("+=======================+");

string znak = Console.ReadLine();
    switch (znak)
    {
        case "1":{
            Console.WriteLine("Stan bohatera");
            if(hp >= 100)
            {
                Console.WriteLine("Bohater jest w dobrej formie."); 
            }
            else if(hp < 100 && hp > 0)
            {
                Console.WriteLine("Bohater jest ranny."); 
            }
            else if(hp <= 0)
            {
                Console.WriteLine("Bohater nie żyje."); 
            }
        }
            break;
        case "2":
            break;
        case "3":
            break;
        case "4": 
            break;
        default: Console.WriteLine("You Died");
            break;  
    }