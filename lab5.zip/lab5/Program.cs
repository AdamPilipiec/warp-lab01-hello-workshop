﻿//Karta bohatera 5.0
Console.ResetColor();

Console.Write("\t\t\t\t\tName? ");      string name = Console.ReadLine()!;              Console.Clear();
Console.Write("\t\t\t\t\tHP? ");        int hp = int.Parse(Console.ReadLine()!);        Console.Clear();
if (hp > 100) // Jeżeli HP > 100 Alert
{
    Console.BackgroundColor = ConsoleColor.Red;
    Console.WriteLine("Alert: HP nie może być większe niż 100!");
    Console.ResetColor();

    while(hp!=100)
    {
        Console.Write("\t\t\t\t\tHP? "); 
        hp = int.Parse(Console.ReadLine()!);
        
        if(hp>100){
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("Alert: HP nie może być większe niż 100!");
            Console.ResetColor();
        }
        else
            break;
    }
}
Console.Write("\t\t\t\t\tLvL? ");       int lvl = int.Parse(Console.ReadLine()!);       Console.Clear();
Console.Write("\t\t\t\t\tGold? ");      int gold = int.Parse(Console.ReadLine()!);      Console.Clear();
Console.Write("\t\t\t\t\tPower? ");     int power = int.Parse(Console.ReadLine()!);     Console.Clear();
Console.Write("\t\t\t\t\tPotions? ");   int potions = int.Parse(Console.ReadLine()!);   Console.Clear();
Console.Write("\t\t\t\t\tMap? ");       bool map = bool.Parse(Console.ReadLine()!);     Console.Clear();

string[] znaleziska =
{
    "Mikstura",
    "Klucz",
    "Pochodnia",
    "Zwój"
};

List<string> plecak = new List<string>
{
    "Miecz",
    "Mikstura"
};

List<string> historia = new List<string>();

bool kompas = false;
bool Zyje = hp > 0;
bool LowHP = hp < 25 && Zyje == true;
bool ReadyToGo = Zyje == true && map == true || kompas == true;
bool rich = gold >= 100;
int tura = 1;
int eksploracje = 0;

char znak;
do
{   
    if(hp <= 0) // Jeżeli ma mniej niż 0 lub równe 0 Gane OVER.
    {
        Console.Clear();
        Console.BackgroundColor = ConsoleColor.Red;
        Console.WriteLine("\t\t\t\t\tGAME OVER!");
        Console.WriteLine("\t\t\t\t\t You Died");
        Console.ResetColor();
        break;
    }

    //menu
    Console.WriteLine($"\t\t\t\t\tTura: {tura}");
    Console.WriteLine($"\t\t\t\t\tBohater: {name}");
    Console.WriteLine($"\t\t\t\t\tHP: {hp} | Gold: {gold} | Potions: {potions} |");
    Console.WriteLine("\t\t\t\t\t+===============================+");
    Console.WriteLine("\t\t\t\t\t|Wybierz akcje\t\t\t|");
    Console.WriteLine("\t\t\t\t\t+===============================+");
    Console.WriteLine("\t\t\t\t\t|1 - Eksploruj lochy\t\t|");
    Console.WriteLine("\t\t\t\t\t|2 - Pokaż plecak\t\t|");
    Console.WriteLine("\t\t\t\t\t|3 - Użyj przedmiotu\t\t|");
    Console.WriteLine("\t\t\t\t\t|4 - Dodaj znalezisko\t\t|");
    Console.WriteLine("\t\t\t\t\t|5 - Wyrzuć przedmiot\t\t|");
    Console.WriteLine("\t\t\t\t\t|6 - Pokaż historię\t\t|");
    Console.WriteLine("\t\t\t\t\t|7 - Pokaż statystyki wyprawy\t|");
    Console.WriteLine("\t\t\t\t\t|8 - Zakończ grę\t\t|");
    Console.WriteLine("\t\t\t\t\t+===============================+");

    znak = char.Parse(Console.ReadLine()!);
    switch (znak)
    {
        case '1': //Eksploracja lochów.
                gold += 10;
                hp -= 8;
                tura++;
                eksploracje++;
            break;
        case '2': //Pokaż plecak;
            if(plecak.Count() == 0)
                Console.WriteLine("Plecak jest pusty!");
            else
                for(int i = 0; i < plecak.Count(); i++)
                    Console.WriteLine($"{i+1} {plecak[i]}");
            break;
        case '3': //Użyj przedmiotu
            if(plecak.Count() == 0)
                Console.WriteLine("Plecak jest pusty!");
            else
            {
                for(int i = 0; i < plecak.Count(); i++)
                    Console.WriteLine($"{i+1} {plecak[i]}");
                Console.Write("Którego przedmiotu chcesz użyć? "); int use = int.Parse(Console.ReadLine()!);
                if(plecak[use] == "Miecz")
                    plecak.RemoveAt(use);
                else if(plecak[use] == "Klucz")
                    plecak.RemoveAt(use);
                else if(plecak[use] == "Pochodnia")
                    plecak.RemoveAt(use);
                else if(plecak[use] == "Zwój")
                    plecak.RemoveAt(use);
                else if(plecak[use] == "Mikstura")
                    plecak.RemoveAt(use);
            }
            break;
        /*case '2': //Użycie mikstury
                if(potions > 0)
                {
                    if(hp == 100)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\tAkcja nie możliwa do wykonania (Masz maksymalną ilosć zdrowia)");
                        Console.ResetColor();
                    }
                    else
                    {
                        tura++;
                        potions--;
                        if(hp + 20 > 100)
                            hp = 100;
                        else
                            hp += 20;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tAkcja nie możliwa do wykonania (Brak dostępnych mikstur)");
                    Console.ResetColor();
                }
            break;*/
        /*case '3': // Odpoczynek
                if(gold >= 3)
                {
                    if(hp == 100)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\tAkcja nie możliwa do wykonania (Masz maksymalną ilosć zdrowia)");
                        Console.ResetColor();
                    }
                    else if(hp + 5 > 100)
                    {
                        hp = 100;
                        gold -= 3;
                        tura++;
                    }
                    else
                    {
                        hp += 5;
                        gold -= 3;
                        tura++;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tAkcja nie możliwa do wykonania (Nie wystarczająca ilość złota)");
                    Console.ResetColor();
                }
            break;*/
        case '4': // Pokaż statystyki

                Console.Clear();
                //karta
                Console.WriteLine("\t\t\t\t\t+=======================+");
                Console.WriteLine($"\t\t\t\t\t|Name: {name}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Hp: {hp}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|LvL: {lvl}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Gold: {gold}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Power: {power}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Potions: {potions}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Map: {map}\t\t|");
                Console.WriteLine("\t\t\t\t\t+-----------------------+");
                if (Zyje == true)
                {
                    Console.Write("\t\t\t\t\t|");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Żyje: {Zyje}");
                    Console.ResetColor();
                    Console.WriteLine("\t\t|");
                }
                else
                {
                    Console.Write("\t\t\t\t\t|");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Żyje: {Zyje}");
                    Console.ResetColor();
                    Console.WriteLine("\t\t|");
                }
                Console.WriteLine($"\t\t\t\t\t|LowHp: {LowHP}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|ReadyToGo: {ReadyToGo}\t|");
                Console.WriteLine($"\t\t\t\t\t|Rich: {rich}\t\t|");
                Console.WriteLine("\t\t\t\t\t+=======================+");

            break;
        case '5': // Zakończ grę
                Console.WriteLine("\t\t\t\t\tDo zobaczenia!");
            break;    
        default: 
                Console.Clear();
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("\t\t\t\t\tGAME OVER!");
                Console.WriteLine("\t\t\t\t\t You Died");
                Console.ResetColor();
            break;  
    }

}while(znak != '5');