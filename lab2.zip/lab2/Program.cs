﻿//Console.WriteLine("Hello, World!");

/*
string imie = Console.ReadLine();
char symbol = char.Parse(Console.ReadLine());
int poziom = int.Parse(Console.ReadLine());
int zloto = int.Parse(Console.ReadLine());
double waga = double.Parse(Console.ReadLine());
bool ma_mape = bool.Parse(Console.ReadLine());

Console.WriteLine($"Imie: {imie}");
Console.WriteLine($"Symbol: {symbol}");
Console.WriteLine($"Poziom: {poziom}");
Console.WriteLine($"Złoto: {zloto}");
Console.WriteLine($"Waga: {waga}");
Console.WriteLine($"Ma mape: {ma_mape}");
*/

/*
int pd = 10;
int gold = 100;
Console.WriteLine($"Punkty doświadczenia: {pd}\nZłoto: {gold}");
Console.WriteLine($"+ 25 do doświadczenia: {pd += 25}");
Console.WriteLine($"doświadczenie x2: {pd *= 2}");
Console.WriteLine($"Opłata za wejscie na arene (8): {gold -= 8}");
Console.WriteLine($"Nagroda za wygraną (15): {gold += 15}");
Console.WriteLine($"zdobyte doświadczenie +1: {pd++}");
*/

/*
int racje = int.Parse(Console.ReadLine());
int team = int.Parse(Console.ReadLine());
int days = int.Parse(Console.ReadLine());

Console.WriteLine($"Liczba pelnych racji na sobe: {racje/team}");
Console.WriteLine($"Pozostale racje: {racje%team}");
Console.WriteLine($"Dzienne racje na druzyne: {racje/team/days*team}");
Console.WriteLine($"Radzie dzienne na osobe: {racje/team/days}");
*/


/*
string imie = Console.ReadLine();
int mhp = int.Parse(Console.ReadLine());
int chp = int.Parse(Console.ReadLine());
int ad = int.Parse(Console.ReadLine());
int s = int.Parse(Console.ReadLine());
double r = double.Parse(Console.ReadLine());
int qwe = int.Parse(Console.ReadLine());
bool zyje = chp > 0;
bool fhp = mhp == chp;

Console.WriteLine($"obrazenia zwyklaego ataku: {ad + s}");
Console.WriteLine($"obrazenia ataku specjalnego {(ad + s)*r}");
Console.WriteLine($"lonczne obrazenia {qwe*(ad+s)+(ad+s)*r}");
Console.WriteLine($"%HP: {chp*100/mhp}");
Console.WriteLine($"Zyje: {zyje}");
Console.WriteLine($"Pelne zdrowie: {fhp}");
*/