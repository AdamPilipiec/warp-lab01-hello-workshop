﻿//Console.WriteLine("Hello, World!");

/*
Console.WriteLine("+--------------------------+");
Console.WriteLine("|       WIZYTÓWKA          |");
Console.WriteLine("+--------------------------+");
Console.WriteLine("| Imię: Lena               |");
Console.WriteLine("| Wiek: 19                 |");
Console.WriteLine("| Gra: Stardew Valley      |");
Console.WriteLine("+--------------------------+");
*/

/*
Console.Write("Jak masz na imie? ");
string? imie = Console.ReadLine();
Console.Write("Jaki jest twój ulubiony kolor? ");
string? kolor = Console.ReadLine();
Console.WriteLine($"Cześć,{imie} {kolor} to świetny kolor na płaszcz poszukiwacza przygód.");
*/

/*
Console.WriteLine("Ile masz lat? ");
int wiek = int.Parse(Console.ReadLine());
Console.WriteLine($"za rok {wiek + 1}, za 5 lat {wiek + 5}");
*/

/*
Console.WriteLine("Km do celu: ");
    int do_celu = int.Parse(Console.ReadLine());
Console.WriteLine("Liczba pokonanych kilometrów: ");
    int pokonane = int.Parse(Console.ReadLine());

    Console.WriteLine($"podroz bedzie trwala {do_celu/pokonane} dni");
*/

/*
Console.WriteLine("Zlote: ");
    int zlote = int.Parse(Console.ReadLine());
Console.WriteLine("Srebrne: ");
    int srebrne = int.Parse(Console.ReadLine());
Console.WriteLine("Miedziane: ");
    int miedziane = int.Parse(Console.ReadLine());

    int miedziaki = zlote*100 + srebrne*10 + miedziane;
    Console.WriteLine($"w sakwie jest {miedziaki} miedziaków");
*/

/*
Console.WriteLine("Ile chcesz mikstur? ");
    int mikstury = int.Parse(Console.ReadLine());
        Console.WriteLine($"Potrzebne krysztaly: {mikstury * 3}");
        Console.WriteLine($"Potrzebne ziola: {mikstury*2}");
*/

/*
Console.WriteLine("Cena noclegu");
    decimal cena = decimal.Parse(Console.ReadLine());
Console.WriteLine("Ilosc nocy");
    int noce = int.Parse(Console.ReadLine());

    decimal koszt = cena * noce;

    Console.WriteLine($"Caly pobyt wyniesie: {koszt}");
*/

/*
Console.WriteLine("Podaj liczbę sekund: ");
    int czas = int.Parse(Console.ReadLine());
        Console.WriteLine($"Minuty: {czas/60} sekundy: {czas%60}");
*/

/*
Console.WriteLine("Liczba monet: ");
    int monety = int.Parse(Console.ReadLine());
Console.WriteLine("Liczba bohaterów: ");
    int hero = int.Parse(Console.ReadLine());
        if(hero == 0)
            Console.WriteLine("Nie ma bohaterow po monety");
        else
            Console.WriteLine($"Kazdy bohater otrzyma: {monety/hero}, a zostanie {monety%hero} monet");
*/

/*
Console.WriteLine("Obrazenia broni: ");
    int obrazenia = int.Parse(Console.ReadLine());
Console.WriteLine("Premia do siły");
    int premia = int.Parse(Console.ReadLine());
    int atak = obrazenia + premia;
    int atak_spec = atak * 2;
        Console.WriteLine($"Zwykły atak: {atak}");
        Console.WriteLine($"Atak Specjalny {atak_spec}");
        Console.WriteLine($"łączne obrazenia 3 zwyklych atakow i 1 specjalnego: {atak*3+atak_spec}");
*/

string hero = Console.ReadLine();
string kraina = Console.ReadLine();
int dni = int.Parse(Console.ReadLine());
int xp = int.Parse(Console.ReadLine());
int gold = int.Parse(Console.ReadLine());
double srednia = (xp + gold)/2;
    Console.WriteLine($"{hero}\n{kraina}\n{dni}\n{xp}\n{gold}\n{srednia}");
    
