﻿//Karta bohatera 4.0
Console.ResetColor();

Console.Write("\t\t\t\t\tName? "); string name = Console.ReadLine(); Console.Clear();
Console.Write("\t\t\t\t\tHP? "); int hp = int.Parse(Console.ReadLine()); Console.Clear();
Console.Write("\t\t\t\t\tLvL? "); int lvl = int.Parse(Console.ReadLine()); Console.Clear();
Console.Write("\t\t\t\t\tGold? "); int gold = int.Parse(Console.ReadLine()); Console.Clear();
Console.Write("\t\t\t\t\tPower? "); int power = int.Parse(Console.ReadLine()); Console.Clear();
Console.Write("\t\t\t\t\tPotions? "); int potions = int.Parse(Console.ReadLine()); Console.Clear();
Console.Write("\t\t\t\t\tMap? "); bool map = bool.Parse(Console.ReadLine()); Console.Clear();

bool kompas = false;
bool Zyje = hp > 0;
bool LowHP = hp < 25 && Zyje == true;
bool ReadyToGo = Zyje == true && map == true || kompas == true;
bool rich = gold >= 100;
int tura = 1;
int eksploracje = 0;

char znak;
do
{   
    if(hp <= 0) // Jeżeli ma mniej niż 0 lub równe 0 Gane OVER.
    {
        Console.Clear();
        Console.BackgroundColor = ConsoleColor.Red;
        Console.WriteLine("\t\t\t\t\tGAME OVER!");
        Console.WriteLine("\t\t\t\t\t You Died");
        Console.ResetColor();
        break;
    }

    //menu
    Console.WriteLine($"\t\t\t\t\tTura: {tura}");
    Console.WriteLine($"\t\t\t\t\tBohater: {name}");
    Console.WriteLine($"\t\t\t\t\tHP: {hp} | Gold: {gold} | Potions: {potions} |");
    Console.WriteLine("\t\t\t\t\t+=======================+");
    Console.WriteLine("\t\t\t\t\t|Wybierz akcje\t\t|");
    Console.WriteLine("\t\t\t\t\t+=======================+");
    Console.WriteLine("\t\t\t\t\t|1 - Eksploruj lochy\t|");
    Console.WriteLine("\t\t\t\t\t|2 - Użyj mikstury \t|");
    Console.WriteLine("\t\t\t\t\t|3 - odpocznij \t\t|");
    Console.WriteLine("\t\t\t\t\t|4 - Pokaż statystyki \t|");
    Console.WriteLine("\t\t\t\t\t|5 - Zakończ grę\t|");
    Console.WriteLine("\t\t\t\t\t+=======================+");

    znak = char.Parse(Console.ReadLine());
    switch (znak)
    {
        case '1': //Eksploracja lochów.
                gold += 10;
                hp -= 8;
                tura++;
                eksploracje++;
            break;
        case '2': //Użycie mikstury
                if(potions > 0)
                {
                    if(hp == 100)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\tAkcja nie możliwa do wykonania (Masz maksymalną ilosć zdrowia)");
                        Console.ResetColor();
                    }
                    else
                    {
                        tura++;
                        potions--;
                        if(hp + 20 > 100)
                            hp = 100;
                        else
                            hp += 20;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tAkcja nie możliwa do wykonania (Brak dostępnych mikstur)");
                    Console.ResetColor();
                }
            break;
        case '3': // Odpoczynek
                if(gold >= 3)
                {
                    if(hp == 100)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\tAkcja nie możliwa do wykonania (Masz maksymalną ilosć zdrowia)");
                        Console.ResetColor();
                    }
                    else if(hp + 5 > 100)
                    {
                        hp = 100;
                        gold -= 3;
                        tura++;
                    }
                    else
                    {
                        hp += 5;
                        gold -= 3;
                        tura++;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\tAkcja nie możliwa do wykonania (Nie wystarczająca ilość złota)");
                    Console.ResetColor();
                }
            break;
        case '4': // Pokaż statystyki

                Console.Clear();
                //karta
                Console.WriteLine("\t\t\t\t\t+=======================+");
                Console.WriteLine($"\t\t\t\t\t|Name: {name}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Hp: {hp}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|LvL: {lvl}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Gold: {gold}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Power: {power}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Potions: {potions}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|Map: {map}\t\t|");
                Console.WriteLine("\t\t\t\t\t+-----------------------+");
                if (Zyje == true)
                {
                    Console.Write("\t\t\t\t\t|");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Żyje: {Zyje}");
                    Console.ResetColor();
                    Console.WriteLine("\t\t|");
                }
                else
                {
                    Console.Write("\t\t\t\t\t|");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Żyje: {Zyje}");
                    Console.ResetColor();
                    Console.WriteLine("\t\t|");
                }
                Console.WriteLine($"\t\t\t\t\t|LowHp: {LowHP}\t\t|");
                Console.WriteLine($"\t\t\t\t\t|ReadyToGo: {ReadyToGo}\t|");
                Console.WriteLine($"\t\t\t\t\t|Rich: {rich}\t\t|");
                Console.WriteLine("\t\t\t\t\t+=======================+");

            break;

        case '5': // Zakończ grę
                Console.WriteLine("\t\t\t\t\tDo zobaczenia!");
            break;
            
        default: 
                Console.Clear();
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("\t\t\t\t\tGAME OVER!");
                Console.WriteLine("\t\t\t\t\t You Died");
                Console.ResetColor();
            break;  
    }

}while(znak != '5');